/*This code is derived from Visual Basic code developed by :
Chris Yates
cyates@neo.rr.com

This has been ported by Shawn Elliott  [selliott@speedgate.net]

This code comes with no warranty whatsoever and is FREE for distribution without Royalty fees of any kind
*/
#include "stdafx.h"
#include "Windows.h"
#include "Windef.h"

int __stdcall MakeTransparent(HWND,HDC,int,int,int,int,int,int);

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	
    return TRUE;
}

int __stdcall MakeTransparent(HWND WinHandle,HDC SrcHandle,int Red,int Blue, int Green,int Width,int Height,int dat)
{

/*Varaible Declarations*/

int X;
int Y;
int StartX;
int Len;

Len = 0;
StartX = -1;

HRGN CurRgn;
HRGN TempRgn;
bool set;
set = FALSE;
COLORREF Pixel,Transparent;
HDC hdc;

/*Assign our values*/

//hdc = GetDC( SrcHandle );
hdc = SrcHandle;

CurRgn = CreateRectRgn(0, 0, Width, Height);
Transparent = RGB(Red,Green,Blue);

X = 0;
Y = 0;

do
{
	do
	{
		Pixel = GetPixel(hdc,X,Y);
		
		if (Pixel == Transparent)
		{
			if (StartX < 0) StartX = X;
		}
		else
		{
			if (StartX > -1)
			{
				set = TRUE;
				Len = X - StartX;

				if (Len == 0) Len = 1;
				/*This is a Pixel/Set of Pixels that we want to make transparent*/

				TempRgn = CreateRectRgn(StartX,Y,StartX + Len,Y + 1);			/*Create a Temporary Region with this Location*/
				CombineRgn(CurRgn, CurRgn, TempRgn, RGN_DIFF);		/*Combine the Temporary Region with the Created one*/
				DeleteObject(TempRgn);								/*Clean the Temporary Region from Memory*/				
				StartX = -1;
			}
		}
	X = X + 1;

	//If There is a region that has not been combined we do it now

	//Catch any possible Exceptions
	if (X > 800) break;

	if (X > Width) break;


	}while(FALSE == FALSE);

	X = 0;
	StartX = -1;
	Y = Y + 1;

//Catch any Possible Exceptions
if (Y > 600) break;
if (Y > Height) break;

}while(FALSE == FALSE);

/*Now we set the Region to the Calling Handle if there was any changes*/
if (set == TRUE)
{
	SetWindowRgn(WinHandle, CurRgn, TRUE);	/*Set the Region*/
}

ReleaseDC( WinHandle, hdc );
DeleteObject(CurRgn);					/*Clean up the Region we worked with*/

return 0;
} /* End Transparency */